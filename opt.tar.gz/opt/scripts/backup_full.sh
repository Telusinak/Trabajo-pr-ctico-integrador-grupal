#!/bin/bash

help(){
	echo "Uso:"
	echo ""
	echo "$0  <origen>  <destino>"
	echo ""
	echo "Ejemplo:"
	echo ""
	echo "$0 /var/log /backup_dir"
	echo ""
	echo "Opciones:"
	echo ""
	echo "-help	Muestra ayuda"
	exit 0
}

if [[ "$1" == "-help" ]]; then
	help
fi

if [[ $# -ne 2 ]]; then
	echo "Error: Debe especificar <origen> <destino>"
	echo "Use -help para mas informacion."
	exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: El directorio de origen $ORIGEN no existe o no se puede acceder."
	exit 1
fi

if mountpoint -q "$DESTINO"; then
	echo "Destino OK: $DESTINO montado."
else
	echo "Error: El destino $DESTINO no esta montado."
	exit 1
fi

NOMBRE=$(basename "$ORIGEN")

FECHA=$(date +%Y%m%d)

ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

echo "Generando backup..."
tar -czf "${DESTINO}/${ARCHIVO}" "$ORIGEN"

if [[ $? -eq 0 ]]; then
	echo "Backup generado correctamente: ${DESTINO}/${ARCHIVO}"
else
	echo "Error al generar el backup."
	exit 1
fi
